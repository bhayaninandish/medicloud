<?php

    //MySQLi

    $conn= mysqli_connect("project.ctx5wywze0yi.us-east-1.rds.amazonaws.com","admin","admin123","project");

    //checking the connection

    


?>